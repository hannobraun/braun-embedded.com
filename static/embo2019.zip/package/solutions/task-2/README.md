To run this program, connect the LPCXpresso824-MAX board via USB, and run:
```
cargo run
```
