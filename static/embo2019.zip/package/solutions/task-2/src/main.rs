#![no_main]
#![no_std]


extern crate panic_halt;


use cortex_m::asm::nop;
use cortex_m_rt::entry;


#[entry]
fn main() -> ! {
    // Get access to the device's peripherals
    //
    // Only one instance of this struct is allowed to exist, and the `take`
    // method makes sure of that by returning `Option<Peripherals>`. The first
    // time its called, the value returned is `Some(peripherals)`, on
    // subsequent it's `None`.
    //
    // Since we're only calling `take` this one time, we know we're getting the
    // `Some` variant and can safely call `unwrap` to get to the `Peripherals`
    // instance in it.
    let p = lpc82x_pac::Peripherals::take().unwrap();

    // Set PIO0_12 to output
    //
    // Since the pin is assigned to GPIO by default, and the GPIO peripheral is
    // enabled by default, there's nothing else we need to do to prepare this.
    p.GPIO_PORT.dirset0.write(|w|
        unsafe { w.dirsetp().bits(0x1 << 12) }
    );

    // Blink the LED
    loop {
        // Set PIO0_12 output to high. This should disable the LED.
        p.GPIO_PORT.set0.write(|w|
            unsafe { w.setp().bits(0x1 << 12) }
        );

        // Sleep for a while. This is a really primitive way to do it, but it's
        // good enough for this examples.
        for _ in 0 .. 10_000 { nop() }

        // Set PIO0_12 output to low. This should enable the LED.
        p.GPIO_PORT.clr0.write(|w|
            unsafe { w.clrp().bits(0x1 << 12) }
        );

        // Sleep for a while.
        for _ in 0 .. 10_000 { nop() }
    }
}
