#![no_main]
#![no_std]


extern crate panic_halt;


use cortex_m_rt::entry;


#[entry]
fn main() -> ! {
    // Get access to the device's peripherals
    //
    // Only one instance of this struct is allowed to exist, and the `take`
    // method makes sure of that by returning `Option<Peripherals>`. The first
    // time its called, the value returned is `Some(peripherals)`, on
    // subsequent it's `None`.
    //
    // Since we're only calling `take` this one time, we know we're getting the
    // `Some` variant and can safely call `unwrap` to get to the `Peripherals`
    // instance in it.
    let p = lpc82x_pac::Peripherals::take().unwrap();

    // ...

    loop {}
}
