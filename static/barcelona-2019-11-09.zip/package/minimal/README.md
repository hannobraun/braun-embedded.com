To run this program, connect the LPC845-BRK board via USB, and execute:
```
cargo run
```
